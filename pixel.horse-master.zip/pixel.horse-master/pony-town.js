process.env.NODE_ENV = 'production';
require('./src/scripts/server/server');
