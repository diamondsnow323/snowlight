import { Component } from '@angular/core';

@Component({
	selector: 'admin-reports',
	templateUrl: 'admin-reports.pug',
})
export class AdminReports {
}
