import { Component } from '@angular/core';

@Component({
	selector: 'admin-sign-in',
	templateUrl: 'admin-sign-in.pug',
})
export class AdminSignIn {
}
