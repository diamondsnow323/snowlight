import { Component } from '@angular/core';

@Component({
	selector: 'tools-index',
	templateUrl: 'tools-index.pug',
})
export class ToolsIndex {
}
