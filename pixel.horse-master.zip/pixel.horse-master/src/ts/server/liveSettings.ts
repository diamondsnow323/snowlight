import { ServerLiveSettings } from '../common/adminInterfaces';

export const liveSettings: ServerLiveSettings = {
	updating: false,
	shutdown: false,
};
