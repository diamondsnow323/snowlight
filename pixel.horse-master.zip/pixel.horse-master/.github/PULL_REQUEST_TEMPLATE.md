## Briefly describe the changes you've made

  - [Change one]
  - [Change two]
  - [...]

## Screenshots of your new feature (if applicable)

[Only for gameplay or sprite changes and additions]

## Is this related to an existing issue?

[If yes, place the issue number after the # below]

Closes #
